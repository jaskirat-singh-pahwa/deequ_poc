from typing import Dict

from awsglue.utils import getResolvedOptions


def parse_args(input_args) -> Dict[str, str]:
    args = getResolvedOptions(input_args, [
        "JOB_NAME",
        "CONFIG_FILE_BUCKET",
        "CONFIG_FILE_KEY"
    ])

    return args
